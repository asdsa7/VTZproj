﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;

//namespace VTZ.WebUI.Models
//{
//    public class Task
//    {
//        public int TaskId { get; set; }
//        public string Name { get; set; }
//        public string ViewDoc { get; set; }
//        public string DocNo { get; set; }
//        public decimal Section { get; set; }
//    }
//}